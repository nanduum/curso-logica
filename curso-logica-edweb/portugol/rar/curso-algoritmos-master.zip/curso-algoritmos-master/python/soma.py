x: int; y: int; soma: int

x = int(input("Digite o valor de X: "))
y = int(input("Digite o valor de Y: "))

soma = x + y

print(f"SOMA = {soma}")