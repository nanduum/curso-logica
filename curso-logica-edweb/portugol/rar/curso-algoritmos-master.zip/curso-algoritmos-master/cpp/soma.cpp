#include <iostream>

using namespace std;

int main(){
    int x, y, soma;

    cout << "Digite o valor de X: ";
    cin >> x;

    cout << "Digite o valor de Y: ";
    cin >> y;

    soma = x + y;

    cout << "SOMA = " << soma << endl;

	return 0;
}
